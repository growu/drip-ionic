package com.keepdays.weidaka.wxapi;

public class WXPayEntryActivity extends EntryActivity {

}
