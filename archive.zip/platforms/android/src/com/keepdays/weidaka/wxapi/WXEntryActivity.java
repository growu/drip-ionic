package com.keepdays.weidaka.wxapi;

public class WXEntryActivity extends EntryActivity {
}
