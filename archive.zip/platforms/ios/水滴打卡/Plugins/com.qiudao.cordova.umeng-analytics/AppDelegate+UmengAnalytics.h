//
//  AppDelegate+UmengAnalytics.h
//
//  Created by Landys on 4/16/15.
//
//

#import "AppDelegate.h"

@interface AppDelegate (UmengAnalytics)

@end
